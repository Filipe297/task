import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-tab3',
  standalone: true,
  templateUrl: './tab3.page.html',
  styleUrls: ['./tab3.page.scss'],
  imports: [CommonModule, IonicModule] // Garante que os componentes Ionic sejam reconhecidos
})

export class Tab3Page {
  user = {
    name: 'Carlos',
    imageUrl: 'https://via.placeholder.com/80'
  };

  workers = [
    {
      name: 'Johnny',
      address: 'Rua das Flores, 123',
      imageUrl: 'https://via.placeholder.com/80',
      profissao: "Encanador",
      servico: 'Trocar encanamento',
      valor: 'R$100',
      showServices: true
    },
    {
      name: 'João Oliveira',
      address: 'Avenida Central, 456',
      imageUrl: 'https://via.placeholder.com/80',
      profissao: "Eletricista",
      servico: 'Trocar afiação',
      valor: 'R$100',
      showServices: true
    },
    {
      name: 'Ana Silva',
      address: 'Rua X, 123',
      imageUrl: 'https://via.placeholder.com/80',
      profissao: "Engenheiro",
      servico: 'Engenheiro Consultor',
      valor: 'R$100',
      showServices: true
    },
    {
      name: 'José carlos',
      address: 'Rua general san martin, 123',
      imageUrl: 'https://via.placeholder.com/80',
      profissao: "Engenheiro",
      servico: 'Editor',
      valor: 'R$200',
      showServices: true
    }
  ];

  toggleServices(worker: { showServices: boolean }) {
  worker.showServices = worker.showServices;
  }

  redirecionar_(){
  location.href = '/minhas-solicitacoes'
  }
}