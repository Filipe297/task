import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: 'login.page.html',
  styleUrls: ['login.page.scss'],
  standalone: true,
  imports: [IonicModule, ReactiveFormsModule]
})
export class LoginPage {
  email = new FormControl('');
  senha = new FormControl('');

  constructor(private router: Router) {}

  login() {
    if (this.email.value === 'carlos@gmail.com' && this.senha.value === '123') {
      location.href = '/inicial';
     // Redireciona para a página de abas
      //alert('Credenciais aceitas.');
    } else {
      alert('Credenciais inválidas.');
    }
  }
}
