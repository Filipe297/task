import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./login/login.page').then( m => m.LoginPage),
  },
  {
    path: 'requests',
    loadComponent: () => import('./requests/requests.page').then( m => m.RequestsPage)
  },
  {
    path: 'login',
    loadComponent: () => import('./login/login.page').then( m => m.LoginPage)
  }, 
  {
    path: 'inicial',
    loadComponent: () => import('./tab3/tab3.page').then(m => m.Tab3Page),
    // minhas-solicitacoes loadChildren: () => import('./tabs/tabs.routes').then((m) => m.routes),
  }, 
  {
    path: 'minhas-solicitacoes',
    loadComponent: () => import('./tab2/tab2.page').then(m => m.Tab2Page),
    // loadChildren: () => import('./tabs/tabs.routes').then((m) => m.routes),
  }
];
