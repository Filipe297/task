import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-requests',
  templateUrl: 'requests.page.html',
  styleUrls: ['requests.page.scss'],
  standalone: true, // ESSENCIAL PARA STANDALONE
  imports: [IonicModule] // Importa os componentes do Ionic
})
export class RequestsPage {
  serviceRequests = [
    { clientName: 'Ana Silva', serviceType: 'Encanamento' },
    { clientName: 'João Oliveira', serviceType: 'Eletricista' },
    { clientName: 'Mariana Costa', serviceType: 'Faxina' }
  ];
}
