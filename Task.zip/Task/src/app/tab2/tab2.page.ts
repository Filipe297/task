import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { AlertController, ToastController } from '@ionic/angular'; // Importando os controladores

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule]
})
export class Tab2Page {
  serviceRequests = [
    { id: 'req001', clientName: 'Ana Silva', contact: 'ana@email.com', address: 'Rua X, 123', securityCode: 'ABC123', serviceType: 'Engenheiro Consultor', status: 'aguardando', valor: 'R$100' },
    { id: 'req002', clientName: 'João Oliveira', contact: 'joao@email.com', address: 'Avenida Central, 456', securityCode: 'XYZ789', serviceType: 'Trocar afiação', status: 'aguardando', valor: 'R$100' }
  ];

  constructor(private alertController: AlertController, private toastController: ToastController) {}

  async acceptRequest(request: any) {
    const alert = await this.alertController.create({
      header: 'Confirmar Aceite',
      message: `Deseja aceitar o serviço de ${request.serviceType} do cliente ${request.clientName}?`,
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        { 
          text: 'Aceitar',
          handler: () => {
            console.log(`Solicitação ${request.id} aceita.`);
            this.serviceRequests = this.serviceRequests.filter(req => req.id !== request.id);
            this.presentToast('Solicitação aceita com sucesso!', 'success');
          }
        }
      ]
    });

    await alert.present();
  }

  async rejectRequest(request: any) {
    const alert = await this.alertController.create({
      header: 'Confirmar cancelamento',
      message: `Deseja cancelar o serviço de ${request.serviceType} do(a) colaborador(a) ${request.clientName}?`,
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        { 
          text: 'Confirmar',
          handler: () => {
            console.log(`Solicitação ${request.id} cancelada.`);
            this.serviceRequests = this.serviceRequests.filter(req => req.id !== request.id);
            this.presentToast('Solicitação cancelada!', 'danger');
          }
        }
      ]
    });

    await alert.present();
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color
    });
    await toast.present();

    
  }

  redirecionar_(){
      location.href = '/inicial'
    }
}
