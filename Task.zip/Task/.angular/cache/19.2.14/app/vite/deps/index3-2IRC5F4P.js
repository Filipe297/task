import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-6HCD6MJG.js";
import "./chunk-ZVATTXSA.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
